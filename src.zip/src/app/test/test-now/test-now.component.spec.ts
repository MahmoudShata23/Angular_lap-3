import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TestNowComponent } from './test-now.component';

describe('TestNowComponent', () => {
  let component: TestNowComponent;
  let fixture: ComponentFixture<TestNowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TestNowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TestNowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
