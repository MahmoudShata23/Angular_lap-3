import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-now',
  templateUrl: './test-now.component.html',
  styleUrls: ['./test-now.component.scss']
})
export class TestNowComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
