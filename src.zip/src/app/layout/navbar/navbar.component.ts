import { Component, Input, OnInit } from '@angular/core';
import { Product, Testproduct } from 'src/app/_modules/product/product.modules';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss'],
})
export class NavbarComponent implements OnInit {
  @Input()
  storeData: Testproduct[] = [];
  dropdown = true;

  constructor() {}

  ngOnInit(): void {}
  removeItem(item: Testproduct): void {
    this.storeData.splice(this.storeData.indexOf(item), 1);
  }
}
