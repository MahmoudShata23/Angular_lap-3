export interface Product {
  id?: number;
  name: string;
  price: number;
  discount?: number;
  image: string;
}
export interface Testproduct extends Product {
  counter: number;
}
