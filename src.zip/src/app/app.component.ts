import { Component } from '@angular/core';
import { Product, Testproduct } from './_modules/product/product.modules';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'my-first-angular';
  lastSent: Testproduct[] = [];

  bigData(product: Product) {
    let testAdd: Testproduct = { ...product, counter: 1 };
    let findId = this.lastSent.find((item) => item.id === testAdd.id);
    if (findId) {
      // this.lastSent.forEach((item) => {
      //   if (item.id === product.id) {
      //     item.counter++;
      //   } else {
      //     return;
      //   }
      // });
      findId.counter++;
    } else {
      this.lastSent.push(testAdd);
    }
  }
}
