import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Product } from '../../../_modules/product/product.modules';
@Component({
  selector: 'app-product-item',
  templateUrl: './product-item.component.html',
  styleUrls: ['./product-item.component.scss'],
})
export class ProductItemComponent implements OnInit {
  productArr: Product[] = [
    {
      id: 1,
      name: 'Camera',
      price: 1000,
      discount: 10,
      image: 'https://picsum.photos/200/300',
    },
    {
      id: 2,
      name: 'Computer',
      price: 2000,
      image: 'https://picsum.photos/200/304',
    },
    {
      id: 3,
      name: 'Printer',
      price: 3000,
      discount: 10,
      image: 'https://picsum.photos/200/301',
    },
    {
      id: 4,
      name: 'Labtop',
      price: 4000,
      discount: 10,
      image: 'https://picsum.photos/200/303',
    },
    {
      id: 5,
      name: 'TV',
      price: 6000,
      discount: 10,
      image: 'https://picsum.photos/200/306',
    },
    {
      id: 6,
      name: 'Tablet',
      price: 5000,
      discount: 10,
      image: 'https://picsum.photos/200/309',
    },
    {
      id: 7,
      name: 'Fridge',
      price: 8000,
      discount: 10,
      image: 'https://picsum.photos/200/308',
    },
  ];
  @Output()
  toBigDady: EventEmitter<Product> = new EventEmitter<Product>();

  constructor() {}
  firstRecive(product: Product) {
    this.toBigDady.emit(product);
  }
  ngOnInit(): void {}
}
