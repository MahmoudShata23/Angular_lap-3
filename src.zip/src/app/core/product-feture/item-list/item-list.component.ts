import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { PostService } from 'src/app/post.service';
import { Product } from '../../../_modules/product/product.modules';

@Component({
  selector: 'app-item-list',
  templateUrl: './item-list.component.html',
  styleUrls: ['./item-list.component.scss'],
})
export class ItemListComponent implements OnInit {
  @Input()
  productSpread!: Product;

  @Output()
  firstShare: EventEmitter<Product> = new EventEmitter<Product>();
  constructor(private postService: PostService) {}

  firstStep() {
    this.firstShare.emit(this.productSpread);
  }
  ngOnInit(): void {}
  data: any;
  whenClick() {
    this.postService.getApi().subscribe((response) => {
      console.log(response);
      this.data = response;
    });
  }
}
